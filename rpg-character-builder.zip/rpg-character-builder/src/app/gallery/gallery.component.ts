import { Component } from '@angular/core';

@Component({
  selector: 'app-gallery',
  standalone: true,
  imports: [],
  template: `
    <p>
      gallery works!
    </p>
  `,
  styles: ``
})
export class GalleryComponent {

}
