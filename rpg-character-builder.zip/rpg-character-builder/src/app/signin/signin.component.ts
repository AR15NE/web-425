import { Component } from '@angular/core';

@Component({
  selector: 'app-signin',
  standalone: true,
  imports: [],
  template: `
    <p>
      signin works!
    </p>
  `,
  styles: ``
})
export class SigninComponent {

}
